# ifndef _CRC32_H_
# define _CRC32_H_

unsigned int crc32(unsigned int crc, const void *buf, size_t size);

# endif
